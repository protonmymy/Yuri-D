package com.example.thithuchanh;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class MenuListAdapter extends ArrayAdapter<MenuItem> {
    public MenuListAdapter(Context context, ArrayList<MenuItem> items) {
        super(context, 0, items);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(R.layout.list_item, parent, false);
        }

        MenuItem currentItem = getItem(position);

        ImageView imageView = listItemView.findViewById(R.id.itemImage);
        imageView.setImageResource(currentItem.getImageResource());

        TextView itemName = listItemView.findViewById(R.id.itemName);
        itemName.setText(currentItem.getName());

        return listItemView;
    }
}
