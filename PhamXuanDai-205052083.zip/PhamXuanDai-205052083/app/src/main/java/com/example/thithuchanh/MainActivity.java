package com.example.thithuchanh;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ListView menuList;
    private TextView selectedItemText;
    private TextView itemDescription;
    private ArrayList<MenuItem> menuItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        menuList = findViewById(R.id.menuList);
        selectedItemText = findViewById(R.id.selectedItemText);

        menuItems = new ArrayList<>();
        menuItems.add(new MenuItem(R.drawable.bread, "bread", "Bon Appétit"));
        menuItems.add(new MenuItem(R.drawable.cherrycheesecake, "cherrycheesecake", "Bon Appétit"));
        menuItems.add(new MenuItem(R.drawable.gingerbreadhouse, "gingerbreadhouse", "Bon Appétit"));
        menuItems.add(new MenuItem(R.drawable.hamburger, "hamburger", "Bon Appétit"));
        menuItems.add(new MenuItem(R.drawable.sunnysideupeggs, "sunnysideupeggs", "Bon Appétit"));





        MenuListAdapter adapter = new MenuListAdapter(this, menuItems);
        menuList.setAdapter(adapter);

        menuList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                MenuItem selectedItem = menuItems.get(position);

                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra("imageResource", selectedItem.getImageResource());
                intent.putExtra("itemName", selectedItem.getName());
                intent.putExtra("itemDescription", selectedItem.getDescription());


                startActivity(intent);
            }
        });
    }


}